<html><head>
<title>
	Books
</title>


</head>
<body>
	
	<?php 

	 $con = mysqli_connect('localhost', 'root', 'root','pw7');
  	if (!$con) {
      die('Connection could not be established: ' . mysqli_error($con));}
      

       $query = 'SELECT * FROM Books';
      $data = mysqli_query($con, $query) ;
      $rows = array();
	while($r = mysqli_fetch_assoc($data)) {
    $rows[] = $r;
}
print json_encode($rows);

      ?>
  
</body>
</html>